<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockmyaccountfooter}prestashop>blockmyaccountfooter_b97d23f7cde011d190f39468e146425e'] = 'My account block for your website\'s footer';
$_MODULE['<{blockmyaccountfooter}prestashop>blockmyaccountfooter_abdb95361b4c92488add0a5a37afabcb'] = 'Displays a block with links relative to user accounts.';
$_MODULE['<{blockmyaccountfooter}prestashop>blockmyaccountfooter_ae9ec80afffec5a455fbf2361a06168a'] = 'Manage my customer account';
$_MODULE['<{blockmyaccountfooter}prestashop>blockmyaccountfooter_d95cf4ab2cbf1dfb63f066b50558b07d'] = 'My account';
$_MODULE['<{blockmyaccountfooter}prestashop>blockmyaccountfooter_74ecd9234b2a42ca13e775193f391833'] = 'My orders';
$_MODULE['<{blockmyaccountfooter}prestashop>blockmyaccountfooter_5973e925605a501b18e48280f04f0347'] = 'My returns';
$_MODULE['<{blockmyaccountfooter}prestashop>blockmyaccountfooter_89080f0eedbd5491a93157930f1e45fc'] = 'My merchandise returns';
$_MODULE['<{blockmyaccountfooter}prestashop>blockmyaccountfooter_9132bc7bac91dd4e1c453d4e96edf219'] = 'My credit slips';
$_MODULE['<{blockmyaccountfooter}prestashop>blockmyaccountfooter_e45be0a0d4a0b62b15694c1a631e6e62'] = 'My addresses';
$_MODULE['<{blockmyaccountfooter}prestashop>blockmyaccountfooter_b4b80a59559e84e8497f746aac634674'] = 'Manage my personal information';
$_MODULE['<{blockmyaccountfooter}prestashop>blockmyaccountfooter_63b1ba91576576e6cf2da6fab7617e58'] = 'My personal info';
$_MODULE['<{blockmyaccountfooter}prestashop>blockmyaccountfooter_95d2137c196c7f84df5753ed78f18332'] = 'My vouchers';
$_MODULE['<{blockmyaccountfooter}prestashop>blockmyaccountfooter_c87aacf5673fada1108c9f809d354311'] = 'Sign out';


return $_MODULE;
