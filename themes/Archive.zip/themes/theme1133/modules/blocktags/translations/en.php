<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocktags}prestashop>blocktags_f2568a62d4ac8d1d5b532556379772ba'] = 'Tags block';
$_MODULE['<{blocktags}prestashop>blocktags_b2de1a21b938fcae9955206a4ca11a12'] = 'Adds a block containing your product tags.';
$_MODULE['<{blocktags}prestashop>blocktags_b15e7271053fe9dd22d80db100179085'] = 'This module need to be hooked in a column and your theme does not implement one';
$_MODULE['<{blocktags}prestashop>blocktags_8d731d453cacf8cff061df22a269b82b'] = 'Please complete the "Displayed tags" field.';
$_MODULE['<{blocktags}prestashop>blocktags_73293a024e644165e9bf48f270af63a0'] = 'Invalid number.';
$_MODULE['<{blocktags}prestashop>blocktags_e5b04b8e686367fd0d34e110eb6598c8'] = 'Please complete the "Tags levels" field.';
$_MODULE['<{blocktags}prestashop>blocktags_9b374b52b3bbb02ac62cf53d4db5a075'] = 'Invalid value for "Tags levels". Choose a positive integer number.';
$_MODULE['<{blocktags}prestashop>blocktags_c888438d14855d7d96a2724ee9c306bd'] = 'Settings updated';
$_MODULE['<{blocktags}prestashop>blocktags_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{blocktags}prestashop>blocktags_726cefc6088fc537bc5b18f333357724'] = 'Displayed tags';
$_MODULE['<{blocktags}prestashop>blocktags_34a51d24608287f9b34807c3004b39d9'] = 'Set the number of tags you would like to see displayed in this block. (default: 10)';
$_MODULE['<{blocktags}prestashop>blocktags_81cd72634d64b8ca3c138a9eb14eac51'] = 'Tags levels';
$_MODULE['<{blocktags}prestashop>blocktags_d187fc236d189e377e0611a7622e5916'] = 'Set the number of different tags levels you would like to use. (default: 3)';
$_MODULE['<{blocktags}prestashop>blocktags_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{blocktags}prestashop>blocktags_189f63f277cd73395561651753563065'] = 'Tags';
$_MODULE['<{blocktags}prestashop>blocktags_49fa2426b7903b3d4c89e2c1874d9346'] = 'More about';
$_MODULE['<{blocktags}prestashop>blocktags_4e6307cfde762f042d0de430e82ba854'] = 'No tags have been specified yet.';
$_MODULE['<{blocktags}prestashop>blocktags_70d5e9f2bb7bcb17339709134ba3a2c6'] = 'No tags specified yet';


return $_MODULE;
