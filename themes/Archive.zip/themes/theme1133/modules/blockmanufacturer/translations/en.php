<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_bc3e73cfa718a3237fb1d7e1da491395'] = 'Manufacturers block';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_71087c7035e626bd33c72ae9a7f042af'] = 'Displays a block listing product manufacturers and/or brands.';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_b15e7271053fe9dd22d80db100179085'] = 'This module need to be hooked in a column and your theme does not implement one';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_f8c922e47935b3b76a749334045d61cf'] = 'There is an invalid number of elements.';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_5b2e13ff6fa0da895d14bd56f2cb2d2d'] = 'Please activate at least one system list.';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_f38f5974cdc23279ffe6d203641a8bdf'] = 'Settings updated.';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_bfdff752293014f11f17122c92909ad5'] = 'Use a plain-text list';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_a7c6946ecc7f4ed19c2691a1e7a28f97'] = 'Display manufacturers in a plain-text list.';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Enabled';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disabled';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_2eef734f174a02ae3d7aaafefeeedb42'] = 'Number of elements to display';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_b0fa976774d2acf72f9c62e9ab73de38'] = 'Use a drop-down list';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_56353167778d1520bfecc70c470e6d8a'] = 'Display manufacturers in a drop-down list.';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_2377be3c2ad9b435ba277a73f0f1ca76'] = 'Manufacturers';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_c70ad5f80e4c6f299013e08cabc980df'] = 'More about %s';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_bf24faeb13210b5a703f3ccef792b000'] = 'All manufacturers';
$_MODULE['<{blockmanufacturer}prestashop>blockmanufacturer_1c407c118b89fa6feaae6b0af5fc0970'] = 'No manufacturer';


return $_MODULE;
