<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocklanguages}prestashop>blocklanguages_d33f69bfa67e20063a8905c923d9cf59'] = 'Language selector block';
$_MODULE['<{blocklanguages}prestashop>blocklanguages_5bc2cbadb5e09b5ef9b9d1724072c4f9'] = 'Adds a block allowing customers to select a language for your store\'s content.';


return $_MODULE;
