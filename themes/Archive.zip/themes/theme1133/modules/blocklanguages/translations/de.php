<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocklanguages}prestashop>blocklanguages_5bc2cbadb5e09b5ef9b9d1724072c4f9'] = 'Fügt einen Block zur Auswahl der Shop-Sprache für den Kunden hinzu.';


return $_MODULE;
