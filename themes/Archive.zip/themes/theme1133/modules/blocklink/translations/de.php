<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocklink}prestashop>blocklink_fc738410141e4ec0c0319a81255a1431'] = 'Block Links';
$_MODULE['<{blocklink}prestashop>blocklink_baa2ae9622a47c3217d725d1537e5187'] = 'Fügt einen Block mit zusätzlichen Links hinzu';
$_MODULE['<{blocklink}prestashop>blocklink_8d85948ef8fda09c2100de886e8663e5'] = 'Sind Sie sicher, dass Sie alle Ihre Links löschen wollen?';
$_MODULE['<{blocklink}prestashop>blocklink_33476c93475bba83cdcaac18e09b95ec'] = 'Das Modul kann nur an eine Spalte angedockt werden. Die gibt es aber in diesem Template nicht';
$_MODULE['<{blocklink}prestashop>blocklink_666f6333e43c215212b916fef3d94af0'] = 'Sie müssen alle Felder ausfüllen.';
$_MODULE['<{blocklink}prestashop>blocklink_9394bb34611399534ffac4f0ece96b7f'] = 'Falsche URL';
$_MODULE['<{blocklink}prestashop>blocklink_3da9d5745155a430aac6d7de3b6de0c8'] = 'Link wurde erfolgreich hinzugefügt';
$_MODULE['<{blocklink}prestashop>blocklink_898536ebd630aa3a9844e9cd9d1ebb9b'] = 'Bei der Link-Erstellung iste ein Fehler aufgetreten';
$_MODULE['<{blocklink}prestashop>blocklink_b18032737875f7947443c98824103a1f'] = 'Das Feld "Name" darf nicht leer bleiben';
$_MODULE['<{blocklink}prestashop>blocklink_43b38b9a2fe65059bed320bd284047e3'] = 'Das Feld "Name" ist ungültig';
$_MODULE['<{blocklink}prestashop>blocklink_eb74914f2759760be5c0a48f699f8541'] = 'Ein Fehler ist bei der Titel-Aktualisierung aufgetreten';
$_MODULE['<{blocklink}prestashop>blocklink_5c0f7e2db8843204f422a369f2030b37'] = 'Der Blocktitel ist erfolgreich aktualisiert worden';
$_MODULE['<{blocklink}prestashop>blocklink_5d73d4c0bcb035a1405e066eb0cdf832'] = 'Ein Fehler ist beim Löschen des Links aufgetreten';
$_MODULE['<{blocklink}prestashop>blocklink_9bbcafcc85be214aaff76dffb8b72ce9'] = 'Der Link ist erfolgreich gelöscht worden';
$_MODULE['<{blocklink}prestashop>blocklink_7e5748d8c44f33c9cde08ac2805e5621'] = 'Bestellsortierung aktualisiert';
$_MODULE['<{blocklink}prestashop>blocklink_46cff2568b00bc09d66844849d0b1309'] = 'Beim Setup der Bestellsortierung ist ein Fehler aufgetreten';
$_MODULE['<{blocklink}prestashop>blocklink_449f6d82cde894eafd3c85b6fa918f89'] = 'ID Link';
$_MODULE['<{blocklink}prestashop>blocklink_63a11faa3a692d4e00fa8e03bbe8a0d6'] = 'Link';
$_MODULE['<{blocklink}prestashop>blocklink_e6b391a8d2c4d45902a23a8b6585703d'] = 'URL';
$_MODULE['<{blocklink}prestashop>blocklink_387a8014f530f080bf2f3be723f8c164'] = 'Link-Liste';
$_MODULE['<{blocklink}prestashop>blocklink_58e9b25bb2e2699986a3abe2c92fc82e'] = 'Neuen Link hinzufügen';
$_MODULE['<{blocklink}prestashop>blocklink_e124f0a8a383171357b9614a45349fb5'] = 'In neuem Fenster öffnen';
$_MODULE['<{blocklink}prestashop>blocklink_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Aktiviert';
$_MODULE['<{blocklink}prestashop>blocklink_b9f5c797ebbf55adccdd8539a65a0241'] = 'Deaktiviert';
$_MODULE['<{blocklink}prestashop>blocklink_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{blocklink}prestashop>blocklink_9d55fc80bbb875322aa67fd22fc98469'] = 'Shop-Zugehörigkeit.';
$_MODULE['<{blocklink}prestashop>blocklink_d4bc72be9854ed72e4a1da1509021bf4'] = 'Einstellungen';
$_MODULE['<{blocklink}prestashop>blocklink_b22c8f9ad7db023c548c3b8e846cb169'] = 'Block-Name';
$_MODULE['<{blocklink}prestashop>blocklink_85c75f5424ba98bfc9dfc05ea8c08415'] = 'URL Block-Name';
$_MODULE['<{blocklink}prestashop>blocklink_b408f3291aaca11c030e806d8b66ee6d'] = 'Anzeige-Einstellungen';
$_MODULE['<{blocklink}prestashop>blocklink_3c2c4126af13baa9c6949bc7bcbb0664'] = 'Sortierung';
$_MODULE['<{blocklink}prestashop>blocklink_c07fa9efcc1618d6ef1a12d4f1107dea'] = 'neueste zuerst';
$_MODULE['<{blocklink}prestashop>blocklink_e83cb6a9bccb5b3fbed4bbeae17b2d12'] = 'älteste zuerst';


return $_MODULE;
