<?php
$idtabs = array();
$idtabs[] = Tab::getIdFromClassName('AdminSampleDataInstallImprort');
$idtabs[] = Tab::getIdFromClassName('AdminSampleDataInstallExport');
?>